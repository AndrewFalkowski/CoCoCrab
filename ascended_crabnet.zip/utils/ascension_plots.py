#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 12 14:46:24 2021

@author: andrewf
"""

# ascension plots

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns


def ascension_plot(losses, bulk_mods, bunc, epoch):
  
  colors = sns.color_palette('mako', 2)
  fig, ax1 = plt.subplots()
  epochs = np.arange(epoch)

  color = colors[1]
  ax1.set_xlabel('Epoch')
  ax1.set_ylabel('Loss', color=color)
  ax1.plot(losses, color=color, mec='k', alpha=0.35, marker='s')
  ax1.tick_params(axis='y', labelcolor=color)
  ax1.tick_params(direction='in',
                      length=7,top=True, right=True)

  minor_locator_x = AutoMinorLocator(2)
  minor_locator_y = AutoMinorLocator(2)
  ax1.get_xaxis().set_minor_locator(minor_locator_x)
  ax1.get_yaxis().set_minor_locator(minor_locator_y)
  plt.tick_params(which='minor',
                  direction='in', labelcolor=color,
                  length=4,
                  right=True,
                  top=True)



  ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

  color = colors[0]
  ax2.set_ylabel('Bulk Modulus', color=color)  # we already handled the x-label with ax1
  # ax2.plot(bulk_mods, color=color, mec='k', alpha=0.35, marker='o')
  ax2.errorbar(epochs, bulk_mods, yerr=bunc, color=color, mec='k', alpha=0.35, marker='o')
  ax2.tick_params(axis='y', labelcolor=color, direction='in',
                      length=7)

  minor_locator_x = AutoMinorLocator(2)
  minor_locator_y = AutoMinorLocator(2)
  ax2.get_xaxis().set_minor_locator(minor_locator_x)
  ax2.get_yaxis().set_minor_locator(minor_locator_y)
  plt.tick_params(which='minor',
                  direction='in', labelcolor=color,
                  length=4,
                  right=True,
                  top=True)

  fig.tight_layout()  # otherwise the right y-label is slightly clipped
  plt.show()


