Trained weights: http://doi.org/10.5281/zenodo.4321168
See the GitHub for more information: https://github.com/anthony-wang/CrabNet